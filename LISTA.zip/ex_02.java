import java.util.Scanner;


public class par_ou_impar {

    public static void main(String[] args){

        Scanner teclado = new Scanner(System.in);
        int numero;

        System.out.println("Informe um numero inteiro:");
        numero = teclado.nextInt();

        if (numero % 2 == 0){
            System.out.println("O numero é par");
        }else{
            System.out.println("O numero é impar");
        }
    }
}
