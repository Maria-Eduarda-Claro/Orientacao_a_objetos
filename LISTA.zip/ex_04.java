import java.util.Scanner;


public class ex_04 {

    public static void main(String[] args){
        Scanner teclado = new Scanner(System.in);
        int numero1;
        int numero2;
        int numero3;


        System.out.print("digite o primeiro número: ");
        numero1 = teclado.nextInt();

        System.out.print("digite o segundo número: ");
         numero2 = teclado.nextInt();

        System.out.print("digite o terceiro número: ");
         numero3 = teclado.nextInt();

        if( ( numero1 > numero2 && numero1 > numero3 ) && ( numero2 > numero3 ) ) {
            System.out.println(numero1);
            System.out.println(numero2);
            System.out.println(numero3);
        }
        else if( ( numero1 > numero2 && numero1 > numero3 ) && ( numero3 > numero2 ) ) {
            System.out.println(numero1);
            System.out.println(numero3);
            System.out.println(numero2);
        }
        else if( ( numero2 > numero1 && numero2 > numero3 ) && ( numero1 > numero3 ) ) {
            System.out.println(numero2);
            System.out.println(numero1);
            System.out.println(numero3);
        }
        else if( ( numero2 > numero1 && numero2 > numero3 ) && ( numero3 > numero1 ) ) {
            System.out.println(numero2);
            System.out.println(numero3);
            System.out.println(numero1);
        }
        else if( ( numero3 > numero1 && numero3 > numero2 ) && ( numero1 > numero2 ) ) {
            System.out.println(numero3);
            System.out.println(numero1);
            System.out.println(numero2);
        }
        else if( ( numero3 > numero1 && numero3 > numero2) && ( numero2 > numero1 ) ) {
            System.out.println(numero3);
            System.out.println(numero2);
            System.out.println(numero1);
        }


    }
}
