import java.util.Scanner;

public class ex_05 {

    public static void main(String[] args){
        Scanner teclado = new Scanner(System.in);



        System.out.println("Informe em qual turno você estuda, m = matutimo, v = vespertino, n = noturno");
        String turno = teclado.nextLine();

        if (turno.equals("m")){
            System.out.print("Bom dia!");}
        if (turno.equals("v")){
            System.out.print("Boa tarde!");}
        if (turno.equals("n")){
            System.out.print("Boa noite!");}
        else{
            System.out.println("Valor invalido");
        }

    }



}
