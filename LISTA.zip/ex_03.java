import java.util.Scanner;


public class ex_03 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double valor1;
        double valor2;
        double valor3;

        System.out.println("Informe o valor do produto 1 :");
        valor1 = teclado.nextDouble();

        System.out.println("Informe o valor do produto 2 :");
        valor2 = teclado.nextDouble();

        System.out.println("Informe o valor do produto 3 :");
        valor3 = teclado.nextDouble();


        if ((valor1 < valor2) && (valor1 < valor3)) {
            System.out.println("O produto 1 é o que você deve comprar");
        }
        if ((valor2 < valor1) && (valor2 < valor3)) {
            System.out.println("O produto 2 é o que você deve comprar");
        }
        if ((valor3 < valor1) && (valor3 < valor2)) {
            System.out.println("O produto 3 é o que você deve comprar");
        }
    }

}