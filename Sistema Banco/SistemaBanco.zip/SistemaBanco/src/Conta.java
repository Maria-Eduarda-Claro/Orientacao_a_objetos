public class Conta {
    private int id;
    private Integer numeroConta;
    private String nome;
    private double valor;


    public Conta(){
        this.id = 0;
        this.numeroConta =0;  //metodo construtor = inicializa os objetos como default
        this.nome = "";
        this.valor = 0;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getNumeroConta() {
        return numeroConta;
    }

    public void setNumeroConta(Integer numeroConta) {
        this.numeroConta = numeroConta;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public void sacar(double valor){
        this.valor -= valor;
        System.out.println("Saque realizado com sucesso! Novo saldo" + this.valor);
    }
    public void depositar (double valor){
        this.valor += valor;
        System.out.println("Deposito realizado com sucesso! Novo saldo" + this.valor) ;
    }
}
