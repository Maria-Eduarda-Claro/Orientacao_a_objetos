import java.util.Scanner;

public class Ex04{
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int prato;
        int bebida;

        System.out.println("Escolha seu prato: Arroz, feijao e carne (1), Macarrao frango e mandioca (2), Arroz, maionese e carne assada (3) ");
        prato = entrada.nextInt();

        System.out.println("Escolha sua bebida: coca cola (1), suco de laranja (2), agua tonica (3) ");
        bebida = entrada.nextInt();

        if(prato ==1 && bebida ==1){
            System.out.println("O combo escolhido foi: Arroz, feijao e carne + coca cola" + prato + bebida);
        }
        if (prato == 1 && bebida ==2){
            System.out.println("O combo escolhido foi: Arroz, feijao e carne + suco de laranja" + prato + bebida);
        }
        if (prato == 1 && bebida== 3 ){
            System.out.println("O combo escolhido foi: Arroz, feijao e carne + agua tonica" + prato + bebida);
        }
        if (prato == 2 && bebida ==1){
            System.out.println("O combo escolhido foi: Macarrao, frango e mandioca + coca cola" + prato + bebida);
        }
        if (prato ==2 && bebida ==2){
            System.out.println("O combo escolhido foi: Macarrao, frango e mandioca + suco de laranja" + prato + bebida);
        }
        if (prato == 2 && bebida ==3){
            System.out.println("O combo escolhido foi: Macarrao, frango e mandioca + agua tonica" + prato + bebida);

        }
        if (prato == 3 && bebida ==1){
            System.out.println("O combo escolhido foi: Arroz, maionese e carne assada + coca cola" + prato + bebida);
        }
        if (prato == 3 && bebida == 2){
            System.out.println("O combo escolhido foi: Arroz, maionese e carne assada + suco de laranja" + prato + bebida);
        }
        if (prato == 3 && bebida == 3 ){
            System.out.println("O combo escolhido foi: Arroz, maionese e carne assada + agua tonica" + prato + bebida);
        }
    }
}