import java.util.Scanner;

public class Ex03 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

            System.out.print("Digite um número de 1 a 10: ");
            int numero = entrada.nextInt();
            String[] digitosPorExtenso = {"um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove", "dez"};
            if (numero < 1 || numero > 10) {
                System.out.println("Número inválido.");
            } else {
                System.out.println("O número " + numero + " por extenso é: " + digitosPorExtenso[numero-1]);
            }
            entrada.close();

    }
}
