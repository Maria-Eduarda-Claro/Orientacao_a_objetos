import java.util.Scanner;

public class Ex02 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.println("Informe o nome do usuario:");
        String nome = entrada.next();
        System.out.println("Informe o CPF do usuario:");
       int cpf = entrada.nextInt();
        System.out.println("Informe o telefone do usuario:");
       int telefone = entrada.nextInt();

        System.out.printf("Nome:" + nome + "-");
        System.out.printf("cpf:" + cpf + "-" );
        System.out.printf("telefone:" + telefone  + "-");
    }
    }

