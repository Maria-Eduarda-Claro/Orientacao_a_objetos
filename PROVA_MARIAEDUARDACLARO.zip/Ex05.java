import javax.print.attribute.standard.Media;
import java.util.Scanner;

public class Ex05 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        String nome;
        double nota1;
        double nota2;
        double nota3;
        double media;

        System.out.println("Informe o nome do aluno:");
        nome =entrada.nextLine();
        System.out.println("Informe a nota 1:");
        nota1 = entrada.nextDouble();
        System.out.println("Informe a nota 2:");
        nota2 = entrada.nextDouble();
        System.out.println("Informe a nota 3:");
        nota3 = entrada.nextDouble();

        media = (nota1 + nota2 + nota3)/3;

        if (media < 6) {
            System.out.println("Nome:" + nome);
            System.out.println("Media:" + media);
            System.out.println("Resultado: Reprovado");
        } else if (media >= 6 && media < 7) {
            System.out.println("Nome:" + nome);
            System.out.println("Media:" + media);
            System.out.println("Resultado: Em recuperação");
        } else {
            System.out.println("Nome:" + nome);
            System.out.println("Media:" + media);
            System.out.println("Resultado: Aprovado");
        }



    }
    }


