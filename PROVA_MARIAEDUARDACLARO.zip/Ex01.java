import java.text.*;
import java.util.*;

public class Ex01 {
    public static void main(String[] args) {
        int nota1 =6;
        int nota2 = 5;
        double media1 = (nota1 + nota2)/2;
        System.out.println("Media 1 =" + media1);
        double soma = nota1 + nota2;
        double media2 = soma / 2;
        System.out.println("Media 2 = " + media2);

    }
}
